# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu


# To scale the data using z-score
from sklearn.preprocessing import StandardScaler

from sklearn.cluster import KMeans

# Importing PCA
from sklearn.decomposition import PCA




# Read recipe inputs
preprocessed_data = dataiku.Dataset("Preprocessed_data")
preprocessed_data_df = preprocessed_data.get_dataframe()

data=preprocessed_data_df
data=data.drop(columns=["Age","Income"], axis=1)

scaler = StandardScaler()            # Storing the Standard Scaler function in scaler

df_scaled = scaler.fit_transform(data)     # Fitting the scaler function on the data

df_scaled = pd.DataFrame(df_scaled, columns=data.columns)

distortions = []                                                  # Create a empty list

K = range(2, 7)                                                  # Setting the K range from 2 to 10

for k in K:
    kmeanModel = KMeans(n_clusters=k,random_state=4)                             # Initialize KMeans
    kmeanModel.fit(df_scaled)                                      # Fit KMeans on the data
    distortions.append(kmeanModel.inertia_)  
df = pd.DataFrame({'K': K, 'Distortions': distortions})


# Write recipe outputs
preprocessed_elbowplot_data = dataiku.Dataset("Preprocessed_elbowplot_data")
preprocessed_elbowplot_data.write_with_schema(df)
