# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu


# To scale the data using z-score
from sklearn.preprocessing import StandardScaler

from sklearn.cluster import KMeans

# Importing PCA
from sklearn.decomposition import PCA



# Read recipe inputs
baseline_model_data_preparation = dataiku.Dataset("baseline_model_data_preparation")
baseline_model_data_preparation_df = baseline_model_data_preparation.get_dataframe()


# Compute recipe outputs from inputs
# TODO: Replace this part by your actual code that computes the output, as a Pandas dataframe
# NB: DSS also supports other kinds of APIs for reading and writing data. Please see doc.

data = baseline_model_data_preparation_df # For this sample code, simply copy input to output


scaler = StandardScaler()            # Storing the Standard Scaler function in scaler

df_scaled = scaler.fit_transform(data)     # Fitting the scaler function on the data

df_scaled = pd.DataFrame(df_scaled, columns=data.columns)

distortions = []                                                  # Create a empty list

K = range(2, 13)                                                  # Setting the K range from 2 to 10

for k in K:
    kmeanModel = KMeans(n_clusters=k,random_state=4)                             # Initialize KMeans
    kmeanModel.fit(df_scaled)                                      # Fit KMeans on the data
    distortions.append(kmeanModel.inertia_)  
df = pd.DataFrame({'K': K, 'Distortions': distortions})

# Write recipe outputs
baselinemodel_elbowplotdata = dataiku.Dataset("baselinemodel_elbowplotdata")
baselinemodel_elbowplotdata.write_with_schema(df)
